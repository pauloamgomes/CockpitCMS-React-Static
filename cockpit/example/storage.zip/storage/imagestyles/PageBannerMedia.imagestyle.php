<?php
 return array (
  '_id' => 'PageBannerMedia5bc9f72269353',
  'name' => 'PageBannerMedia',
  'description' => 'To be used in the page banners with summary',
  'effects' => 
  array (
  ),
  '_created' => 1539962658,
  '_modified' => 1540327994,
  'mode' => 'thumbnail',
  'width' => '1440',
  'height' => '440',
  'anchor' => 'center',
  'quality' => 90,
  'base64' => false,
  'domain' => false,
);