<?php
 return array (
  '_id' => 'BigHero5bc9f6ce0e790',
  'name' => 'BigHero',
  'description' => 'To be used in the BigHero components',
  'effects' => 
  array (
  ),
  '_created' => 1539962574,
  '_modified' => 1540164111,
  'mode' => 'thumbnail',
  'width' => '1440',
  'height' => '400',
  'anchor' => 'center',
  'quality' => 90,
  'base64' => false,
  'domain' => true,
);