<?php
 return array (
  '_id' => 'Logo5bcd0485cf882',
  'name' => 'Logo',
  'description' => '',
  'effects' => 
  array (
  ),
  '_created' => 1540162693,
  '_modified' => 1540164121,
  'mode' => 'fitToHeight',
  'width' => '',
  'height' => '60',
  'anchor' => 'center',
  'quality' => 90,
  'base64' => false,
  'domain' => true,
);