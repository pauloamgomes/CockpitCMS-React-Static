<?php
 return array (
  '_id' => 'Square5bcbaff8985e0',
  'name' => 'Square',
  'description' => '',
  'effects' => 
  array (
  ),
  '_created' => 1540075512,
  '_modified' => 1540327973,
  'mode' => 'thumbnail',
  'width' => '550',
  'height' => '550',
  'anchor' => 'center',
  'quality' => 90,
  'base64' => false,
  'domain' => false,
);