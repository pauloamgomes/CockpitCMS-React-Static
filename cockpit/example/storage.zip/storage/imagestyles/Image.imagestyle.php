<?php
 return array (
  '_id' => 'Image5bcb9c152f996',
  'name' => 'Image',
  'description' => '',
  'effects' => 
  array (
  ),
  '_created' => 1540070421,
  '_modified' => 1540327991,
  'mode' => 'fitToWidth',
  'width' => '1110',
  'height' => '',
  'anchor' => 'center',
  'quality' => 90,
  'base64' => false,
  'domain' => false,
);