<?php
 return array (
  '_id' => 'Card5bcaff30450c3',
  'name' => 'Card',
  'description' => 'To be used in cards',
  'effects' => 
  array (
  ),
  '_created' => 1540030256,
  '_modified' => 1540327998,
  'mode' => 'thumbnail',
  'width' => '220',
  'height' => '160',
  'anchor' => 'center',
  'quality' => 90,
  'base64' => false,
  'domain' => false,
);